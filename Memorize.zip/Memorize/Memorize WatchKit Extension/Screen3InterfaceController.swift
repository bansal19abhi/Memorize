//
//  Screen3InterfaceController.swift
//  Memorize WatchKit Extension
//
//  Created by Abhishek Bansal on 2019-07-10.
//  Copyright © 2019 Abhishek Bansal. All rights reserved.
//

import WatchKit
import Foundation
import WatchConnectivity


class Screen3InterfaceController: WKInterfaceController, WCSessionDelegate {
   
    func session(_ session: WCSession, activationDidCompleteWith activationState: WCSessionActivationState, error: Error?) {
        
    }
    
    
    //MARK: Labels
    
    @IBOutlet weak var imgAnimalA: WKInterfaceImage!
    @IBOutlet weak var imgAnimalB: WKInterfaceImage!
    @IBOutlet weak var imgAnimalC: WKInterfaceImage!
    @IBOutlet weak var imgAnimalD: WKInterfaceImage!
    @IBOutlet weak var wlLabel: WKInterfaceLabel!
    @IBOutlet weak var playAgainLabel: WKInterfaceLabel!
    
    
    //GL
    var imgArray : [Int] = [0,1,2,3]
    var img0 = [Int]()
    
    

    override func awake(withContext context: Any?) {
        super.awake(withContext: context)
        
        // Configure interface objects here.
    }

    override func willActivate() {
        // This method is called when watch view controller is about to be visible to user
        super.willActivate()
        
        //shuffling the images and displaying in random order
        self.imgArray.shuffle()
        img0 = self.imgArray
        
        self.playAgainLabel.setHidden(true)
        self.wlLabel.setHidden(true)
       
        imgAnimalA.setImageNamed("\(imgArray[0])")
        imgAnimalB.setImageNamed("\(imgArray[1])")
        imgAnimalC.setImageNamed("\(imgArray[2])")
        imgAnimalD.setImageNamed("\(imgArray[3])")
        
        //console
        print(imgArray)
        
        // checking the mode: easy/hard
        let mode = UserDefaults.standard.string(forKey: "mode")
        if(mode == "Easy"){
            easy()
        }
        if(mode == "Hard"){
            hard()
        }
        
        // WATCH-CONNECTIVITY
        
        if (WCSession.isSupported()) {
            print("Watch: Phone supports WatchConnectivity!")
            let session = WCSession.default
            session.delegate = self
            session.activate()
        }
        else {
            print("Watch: Phone does not support WatchConnectivity")
        }
        
        
    }
    
    
    override func didDeactivate() {
        // This method is called when watch view controller is no longer visible
        super.didDeactivate()
    }
    
    
    // if mode selected is easy
    func easy(){
        DispatchQueue.main.asyncAfter(deadline: .now() + 3.0) {
            self.imgAnimalA.setImageNamed(nil)
            self.imgAnimalB.setImageNamed(nil)
            self.imgAnimalC.setImageNamed(nil)
            self.imgAnimalD.setImageNamed(nil)
        }
    }
    
     // if mode selected is hard
    func hard(){
        DispatchQueue.main.asyncAfter(deadline: .now() + 1.0) {
            self.imgAnimalA.setImageNamed(nil)
            self.imgAnimalB.setImageNamed(nil)
            self.imgAnimalC.setImageNamed(nil)
            self.imgAnimalD.setImageNamed(nil)
        }
    }
    
    // RECEIVING MESSAGE FROM WATCH
    func session(_ session: WCSession, didReceiveMessage message: [String : Any]) {
        print("WATCH: Got a message!")
        // print(message["sequence"])
        
        var userMemoryRes:[Int] = message["mob-watch"] as! [Int]
        
        print(userMemoryRes)
        print(userMemoryRes[0])
        print(img0[0])
        
        if(userMemoryRes[0] == img0[0]){
            print("Correct Sequence: You Win")
            self.wlLabel.setHidden(false)
            self.playAgainLabel.setHidden(false)
            let userName = UserDefaults.standard.string(forKey: "name")
            self.wlLabel.setText("Congratulations \(userName!), you won!!")
       }
        else{
            print("Incoorect Sequence: You Lose")
            self.wlLabel.setHidden(false)
            self.playAgainLabel.setHidden(false)
            let userName = UserDefaults.standard.string(forKey: "name")
            self.wlLabel.setText("Unfortunately \(userName!), you lost!!")
        }
        
        
    }
    
    // MARK: Button
    @IBAction func seeSeqAgainButton() {
        
        print("See sequence again button pressed")
        
        self.imgArray.shuffle()
        img0 = self.imgArray
        self.wlLabel.setHidden(true)
        self.playAgainLabel.setHidden(true)
        imgAnimalA.setImageNamed("\(imgArray[0])")
        imgAnimalB.setImageNamed("\(imgArray[1])")
        imgAnimalC.setImageNamed("\(imgArray[2])")
        imgAnimalD.setImageNamed("\(imgArray[3])")
        
        let mode = UserDefaults.standard.string(forKey: "mode")
        if(mode == "Easy"){
            easy()
        }
        if(mode == "Hard"){
            hard()
        }
    }
    
    
}
