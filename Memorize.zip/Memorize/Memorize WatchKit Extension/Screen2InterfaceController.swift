//
//  Screen2InterfaceController.swift
//  Memorize WatchKit Extension
//
//  Created by Abhishek Bansal on 2019-07-10.
//  Copyright © 2019 Abhishek Bansal. All rights reserved.
//

import WatchKit
import Foundation


class Screen2InterfaceController: WKInterfaceController {
    
    //MARK: Label
    
    @IBOutlet weak var welcomeNameLabel: WKInterfaceLabel!
    
    

    override func awake(withContext context: Any?) {
        super.awake(withContext: context)
        
        // Configure interface objects here.
    }

    override func willActivate() {
        // This method is called when watch view controller is about to be visible to user
        super.willActivate()
        let userName = UserDefaults.standard.string(forKey: "name")
        welcomeNameLabel.setText("Hey \(userName!), welcome to the game. Choose your difficulty level to start the game.")
    }

    override func didDeactivate() {
        // This method is called when watch view controller is no longer visible
        super.didDeactivate()
    }
    
    // MARK: Buttons
    
    @IBAction func easyButton() {
        print("Easy Mode selected")
        UserDefaults.standard.set("Easy", forKey: "mode")
        self.pushController(withName: "segue2", context: nil)
    }
    
    
    @IBAction func hardButton() {
        print("Hard Mode selected")
        UserDefaults.standard.set("Hard", forKey: "mode")
        self.pushController(withName: "segue2", context: nil)
    }
    
}
