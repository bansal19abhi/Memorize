//
//  ViewController.swift
//  Memorize
//
//  Created by Abhishek Bansal on 2019-07-10.
//  Copyright © 2019 Abhishek Bansal. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }
    // MARK: Button
    
    @IBAction func startGameButton(_ sender: Any) {
        print("Start game button pressed")
    }
    

}

