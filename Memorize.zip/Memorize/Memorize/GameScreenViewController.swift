//
//  GameScreenViewController.swift
//  Memorize
//
//  Created by Abhishek Bansal on 2019-07-11.
//  Copyright © 2019 Abhishek Bansal. All rights reserved.
//

import UIKit
import WatchConnectivity

class GameScreenViewController: UIViewController, WCSessionDelegate {
    
    //GL
    var img1 = [Int]()
   
    // Mark: Watch Connection Function
    func session(_ session: WCSession, activationDidCompleteWith activationState: WCSessionActivationState, error: Error?) {}
    func sessionDidBecomeInactive(_ session: WCSession) {}
    func sessionDidDeactivate(_ session: WCSession) {}
    
    
    // MARK: Screen Start
    override func viewDidLoad() {
        print("Loaded Game Screen")
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        
        //checking if the phone and watch are connected properlyor not
        if (WCSession.isSupported()) {
            print("PHONE: Phone supports Connectivity to watch!")
            let session = WCSession.default
            session.delegate = self
            session.activate()
        }
        else {
            print("PHONE: Phone does not support Connectivity to watch")
        }
    }
    
    //MARK: Button
    @IBAction func birdButton(_ sender: Any) {
        
        print("Bird Selected")
        self.img1.append(0)
        check()
        sendSelectedSeq()
        
    }
    
    @IBAction func catButton(_ sender: Any) {
        print("Cat Selected")
        self.img1.append(1)
        check()
        sendSelectedSeq()
    }
    
    @IBAction func dogButton(_ sender: Any) {
        print("Dog Selected")
        self.img1.append(2)
        check()
        sendSelectedSeq()
    }
    
    @IBAction func snakeButton(_ sender: Any) {
        print("Snake Selected")
        self.img1.append(3)
        check()
        sendSelectedSeq()
    }
    
    //MARK: Func-> send user input to watch to check result
    func sendSelectedSeq(){
        
        if(img1.count == 4){
            if (WCSession.default.isReachable) {
                let userSelection = ["mob-watch": img1]
                // send the message to the watch
                WCSession.default.sendMessage(userSelection, replyHandler: nil)
                img1.removeAll()
                
            }
            else {
                print("PHONE: Cannot find the watch")
            }
        }
        
    }
    
    //MARK: Func-> background console print results
    func check(){
        print(self.img1)
        print("----------")
        print(img1.count)
        
    }
    
}
